


import java.util.Scanner;

public class PolarToCartesian {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicitar al usuario ingresar las coordenadas polares
        System.out.print("Ingrese el radio (r): ");
        double r = scanner.nextDouble();

        System.out.print("Ingrese el ángulo en radianes (θ): ");
        double theta = scanner.nextDouble();

        // Calcular coordenadas cartesianas
        double x = r * Math.cos(theta);
        double y = r * Math.sin(theta);

        // Mostrar resultados
        System.out.println("Coordenadas cartesianas:");
        System.out.println("x = " + x);
        System.out.println("y = " + y);

        // Cerrar el Scanner
        scanner.close();
    }
}